public enum ToolEffect
{
    none,
    watering
}