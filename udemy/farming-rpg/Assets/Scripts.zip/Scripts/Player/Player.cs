using UnityEngine;

public class Player : SingletonMonobehavior<Player>
{
}
